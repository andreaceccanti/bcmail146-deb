
package java.lang;

public class UnsupportedOperationException extends RuntimeException
{
    public UnsupportedOperationException()
    {
    }

    public UnsupportedOperationException(String msg)
    {
        super(msg);
    }
}
