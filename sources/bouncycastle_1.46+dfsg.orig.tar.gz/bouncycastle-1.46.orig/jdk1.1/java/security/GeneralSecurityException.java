
package java.security;

public class GeneralSecurityException extends Exception
{
    public GeneralSecurityException()
    {
    }

    public GeneralSecurityException(String msg)
    {
        super(msg);
    }
}
