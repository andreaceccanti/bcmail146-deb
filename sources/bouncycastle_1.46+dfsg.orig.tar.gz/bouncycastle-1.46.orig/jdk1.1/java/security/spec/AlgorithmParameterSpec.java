
package java.security.spec;

public interface AlgorithmParameterSpec 
{
}
