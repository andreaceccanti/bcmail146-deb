
package java.security.spec;

public interface KeySpec 
{
}
