
package java.security.cert;

public class CertificateEncodingException extends CertificateException
{
    public CertificateEncodingException()
    {
    }

    public CertificateEncodingException(String msg)
    {
        super(msg);
    }
}
