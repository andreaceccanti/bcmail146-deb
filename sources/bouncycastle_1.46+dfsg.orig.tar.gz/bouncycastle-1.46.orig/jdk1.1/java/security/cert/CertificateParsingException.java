
package java.security.cert;

public class CertificateParsingException extends CertificateException
{
    public CertificateParsingException()
    {
    }

    public CertificateParsingException(String msg)
    {
        super(msg);
    }
}
