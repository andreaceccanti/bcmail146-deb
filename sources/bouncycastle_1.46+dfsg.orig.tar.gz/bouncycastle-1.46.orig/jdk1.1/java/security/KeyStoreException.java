
package java.security;

public class KeyStoreException extends GeneralSecurityException
{
    public KeyStoreException()
    {
    }

    public KeyStoreException(String msg)
    {
        super(msg);
    }
}
